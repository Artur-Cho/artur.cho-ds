import java.util.Scanner;

public class Rep3{
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite um número: ");
        int num = s.nextInt();
        int num2 = 0;
        while ( num != 0 ){
            num2 = num + num2;
            System.out.println("O número é diferente de 0, então digite o próximo número: ");
            num= s.nextInt();
            
             
            
        }
        
        System.out.println(num2);
        
        
         
        
        
    }
}