import java.util.Scanner;

public class Rep4{
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        
        System.out.println("Digite um número: ");
        int numero = s.nextInt();
        
        for (int i = 0 ; i <= 10 ; i++){
            
            int mult = numero * i;
            System.out.println(numero + " x " + i + " = " + mult );
            
        }
        
        
    }
}